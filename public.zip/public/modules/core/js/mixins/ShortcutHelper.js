export default {
    methods: {
        pushRoute(route) {
            this.$router.push(route);
        },
    },
};
